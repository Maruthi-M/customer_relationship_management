package com.cts.crm.exception;

public class SubscriptionException extends RuntimeException {

	private static final long serialVersionUID = 5658037804847269080L;

	public SubscriptionException(String message) {
		super(message);
	}
	
}
