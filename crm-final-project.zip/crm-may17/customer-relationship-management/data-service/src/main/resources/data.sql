insert into user values (1,"syed@gmail.com","Syed","syed123","ROLE_ADMIN");
insert into user values (2,"maruthi@gmail.com","Maruthi","maruthi123","ROLE_ADMIN");
insert into user values (3,"rekha@gmail.com","Rekha","rekha123","ROLE_ADMIN");
insert into user values (4,"kalpana@gmail.com","Kalpana","kalpana123","ROLE_ADMIN");