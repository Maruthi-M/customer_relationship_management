package com.cts.crm.service;

public interface SchedulerService {
	
	public void inactiveSubscription();

}
