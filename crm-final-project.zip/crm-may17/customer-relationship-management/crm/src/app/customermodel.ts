export class Customer{
    customerId: number;
    name: string;
    mobileNumber: number;
    email: string;
    circle: string;
    dp: string
}
