package com.cts.crm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.crm.model.Subscription;
@Repository
public interface SubscriptionDao extends JpaRepository<Subscription,Integer>{

}
